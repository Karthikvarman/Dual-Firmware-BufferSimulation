# Dual ESP32 Circular Buffer Simulator for Wokwi

This is a Wokwi online simulator configuration for your dual-ESP32 circular buffer firmware system with real ESP-NOW wireless communication.

## Architecture

### ESP32 Client (Buffer Node)
- Runs circular buffer with 16-slot capacity
- 0.1 Hz periodic telemetry timer (10 seconds)
- ESP-NOW wireless communication
- LED indicators:
  - **Green LED (GPIO 22)**: Head pointer (next write position)
  - **Blue LED (GPIO 23)**: Tail pointer (next read position)
  - **Red LED (GPIO 21)**: Power indicator
  - **Yellow LED (GPIO 19)**: WiFi/ESP-NOW connection status

### ESP32 Server (Gateway)
- Sends telecommands to control client buffer
- UART console for user interaction
- ESP-NOW wireless communication
- Serial monitor at 115200 baud

## Telecommands

- **READ (R)**: Read oldest data and free slot
- **PEEK (P)**: Inspect oldest data without freeing
- **STATUS (S)**: Display buffer diagnostics
- **PAUSE_WR**: Pause periodic telemetry writes
- **RESUME_WR**: Resume periodic telemetry writes
- **RESTART_RD**: Reset read session
- **RESET_BUF**: Clear and reinitialize buffer
- **HELP (?)**: Show command menu

## Using on Wokwi

### Option 1: Using Wokwi's Build System (Recommended)

1. Upload this entire `wokwi_dual_esp` folder to Wokwi
2. Wokwi will automatically build both ESP32 firmwares
3. Open Serial Monitor for ESP32 Server (115200 baud)
4. Type commands to control the client's circular buffer
5. Watch the LEDs on the client visualize buffer state

### Option 2: Pre-built Firmware

If you want to use pre-built firmware:

```bash
# Build client firmware locally
cd esp32_client
idf.py build

# Build server firmware locally
cd ../esp32_server
idf.py build
```

Then update `wokwi.toml` to reference the built firmware:

```toml
[wokwi]
version = 1

[[wokwi.devices]]
name = "esp32_client"
firmware = "esp32_client/build/esp32_client.bin"

[[wokwi.devices]]
name = "esp32_server"
firmware = "esp32_server/build/esp32_server.bin"
```

## How It Works

1. **ESP32 Client** automatically starts collecting telemetry every 10 seconds
2. Data is stored in the 16-slot circular buffer
3. The green LED blinks when data is written (head pointer)
4. The blue LED blinks when data is read (tail pointer)
5. **ESP32 Server** sends commands via ESP-NOW wireless protocol
6. Both ESPs communicate wirelessly without physical connections
7. Use the Serial Monitor on the Server to send telecommands

## LED Indicators

- **Green (Head)**: Blinks when new telemetry is written to buffer
- **Blue (Tail)**: Blinks when data is read from buffer (only if buffer has data)
- **Red (Power)**: Always ON when client is powered
- **Yellow (WiFi)**: ON when ESP-NOW is initialized and ready

## Example Session

```
CMD> STATUS

--- [CIRCULAR BUFFER DIAGNOSTICS] ---
  Total Capacity     : 16 slots
  Active Stored Data : 8 slots (50% utilized)
  Free Slots Avail   : 8 slots
  Next Write Address : Slot #8 (Head)
  Next Read Address  : Slot #0 (Tail)
  Total Writes Done  : 8
  Total Reads Done   : 0
  Memory Full Alarms : 0
  Buffer State       : ACTIVE DATA
  Write Acquisition  : ENABLED

CMD> READ

--- [OLDEST READ TELEMETRY RECORD] ---
  Buffer Slot ID   : #0
  Sequence Number  : 1
  Client Uptime    : 10000 ms
  Free Heap Memory : 245678 bytes
  ...
```

## Hardware Components in Diagram

- 2x ESP32 DevKit C v4
- 4x LEDs (connected to client ESP32 for visualization)
- No wires between ESPs (they communicate wirelessly via ESP-NOW)

## Troubleshooting

- If ESP-NOW fails, check that both ESPs are on the same WiFi channel (channel 1)
- If Serial Monitor shows garbage, ensure baud rate is 115200
- If LEDs don't work, check GPIO connections in diagram.json
