#include <ctype.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "driver/uart.h"
#include "driver/gpio.h"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_now.h"
#include "esp_system.h"
#include "esp_wifi.h"
#include "nvs_flash.h"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/semphr.h"
#include "freertos/task.h"

#include "protocol.h"

#ifndef UART_SCLK_DEFAULT
#define UART_SCLK_DEFAULT UART_SCLK_APB
#endif

static const char *TAG = "ESP32_SERVER";

#define PC_UART_NUM UART_NUM_0
#define PC_UART_BAUD_RATE 115200
#define UART_RX_BUF_SIZE 1024
#define UART_TX_BUF_SIZE 1024
#define UART_QUEUE_DEPTH 20
#define CMD_LINE_MAX_LEN 64
#define WIFI_CHANNEL 1

static const uint8_t s_broadcast_mac[ESP_NOW_ETH_ALEN] = {0xFF, 0xFF, 0xFF,
                                                          0xFF, 0xFF, 0xFF};

static QueueHandle_t s_uart_event_queue = NULL;
static QueueHandle_t s_wireless_rx_queue = NULL;
static uint16_t s_tx_seq = 0U;

static void on_esp_now_recv(const esp_now_recv_info_t *recv_info,
                            const uint8_t *data, int len) {
  (void)recv_info;

  wireless_packet_t pkt;
  if ((data == NULL) || (len <= 0) ||
      ((size_t)len > sizeof(wireless_packet_t))) {
    return;
  }

  memcpy(&pkt, data, (size_t)len);

  BaseType_t xHigherPriorityTaskWoken = pdFALSE;
  if (s_wireless_rx_queue != NULL) {
    xQueueSendFromISR(s_wireless_rx_queue, &pkt, &xHigherPriorityTaskWoken);
    if (xHigherPriorityTaskWoken == pdTRUE) {
      portYIELD_FROM_ISR();
    }
  }
}

static esp_err_t server_send_command(uint8_t opcode, const void *payload,
                                     uint8_t payload_len) {
  wireless_packet_t pkt;
  size_t frame_bytes =
      proto_pack_frame(&pkt, ++s_tx_seq, opcode, payload, payload_len);

  return esp_now_send(s_broadcast_mac, (const uint8_t *)&pkt, frame_bytes);
}

static void print_help_menu(void) {
  const char *menu =
      "\r\n===================================================================="
      "\r\n"
      "           ESP32 TELEMETRY CIRCULAR BUFFER CONTROLLER              \r\n"
      "====================================================================\r\n"
      " Available Telecommands:\r\n"
      "   READ       (R) : Read oldest unread data; frees slot for "
      "rewriting\r\n"
      "   PEEK       (P) : Inspect oldest unread data without advancing "
      "tail\r\n"
      "   STATUS     (S) : Display buffer diagnostics, capacity, & pointers "
      "\r\n"
      "   PAUSE_WR       : Pause 0.1 Hz periodic write telemetry "
      "acquisition\r\n"
      "   RESUME_WR      : Resume periodic write; appends from last written\r\n"
      "   RESTART_RD     : Reset/resume read session\r\n"
      "   RESET_BUF      : Clear & reinitialize circular buffer memory\r\n"
      "   HELP       (?) : Show this telecommand command menu\r\n"
      "====================================================================\r\n"
      "CMD> ";
  printf("%s", menu);
}

static void display_record(const char *label, const telemetry_record_t *record) {
  printf("\r\n--- [%s TELEMETRY RECORD] ---\r\n"
         "  Buffer Slot ID   : #%u\r\n"
         "  Sequence Number  : %lu\r\n"
         "  Client Uptime    : %lu ms\r\n"
         "  Free Heap Memory : %lu bytes\r\n"
         "  Min Free Heap    : %lu bytes\r\n"
         "  Chip Temperature : %d C\r\n"
         "  Wi-Fi RSSI       : %d dBm\r\n"
         "  CPU Frequency    : %lu MHz\r\n",
         label, (unsigned int)record->buffer_slot_id,
         (unsigned long)record->sequence_id,
         (unsigned long)record->timestamp_ms,
         (unsigned long)record->free_heap_bytes,
         (unsigned long)record->min_free_heap_bytes,
         (int)record->chip_temp_c, (int)record->wifi_rssi_dbm,
         (unsigned long)record->cpu_freq_mhz);
}

static void display_diagnostics(const proto_diagnostics_payload_t *diag) {
  const uint32_t utilization =
      diag->capacity > 0U ? diag->count * 100U / diag->capacity : 0U;

  printf("\r\n--- [CIRCULAR BUFFER DIAGNOSTICS] ---\r\n"
         "  Total Capacity     : %lu slots\r\n"
         "  Active Stored Data : %lu slots (%lu%% utilized)\r\n"
         "  Free Slots Avail   : %lu slots\r\n"
         "  Next Write Address : Slot #%lu (Head)\r\n"
         "  Next Read Address  : Slot #%lu (Tail)\r\n"
         "  Total Writes Done  : %lu\r\n"
         "  Total Reads Done   : %lu\r\n"
         "  Memory Full Alarms : %lu\r\n"
         "  Buffer State       : %s\r\n"
         "  Write Acquisition  : %s\r\n"
         "====================================================================\r\n"
         "CMD> ",
         (unsigned long)diag->capacity, (unsigned long)diag->count,
         (unsigned long)utilization,
         (unsigned long)(diag->capacity - diag->count),
         (unsigned long)diag->write_index, (unsigned long)diag->read_index,
         (unsigned long)diag->total_writes, (unsigned long)diag->total_reads,
         (unsigned long)diag->full_exceptions,
         diag->is_full ? "FULL" : (diag->is_empty ? "EMPTY" : "ACTIVE DATA"),
         diag->write_enabled ? "ENABLED" : "PAUSED");
}

static void process_console_command(char *line) {
  size_t start = 0U;
  size_t end = strlen(line);

  while (start < end && isspace((unsigned char)line[start])) {
    start++;
  }
  while (end > start && isspace((unsigned char)line[end - 1U])) {
    end--;
  }
  line[end] = '\0';

  for (size_t i = start; line[i] != '\0'; i++) {
    line[i] = (char)toupper((unsigned char)line[i]);
  }

  const char *command = line + start;
  uint8_t opcode = 0;

  if (strcmp(command, "READ") == 0 || strcmp(command, "R") == 0) {
    opcode = CMD_READ_REQ;
  } else if (strcmp(command, "PEEK") == 0 || strcmp(command, "P") == 0) {
    opcode = CMD_PEEK_REQ;
  } else if (strcmp(command, "STATUS") == 0 || strcmp(command, "S") == 0) {
    opcode = CMD_STATUS_REQ;
  } else if (strcmp(command, "PAUSE_WR") == 0) {
    opcode = CMD_PAUSE_WR_REQ;
  } else if (strcmp(command, "RESUME_WR") == 0) {
    opcode = CMD_RESUME_WR_REQ;
  } else if (strcmp(command, "RESTART_RD") == 0) {
    opcode = CMD_RESTART_RD_REQ;
  } else if (strcmp(command, "RESET_BUF") == 0) {
    opcode = CMD_RESET_BUF_REQ;
  } else if (strcmp(command, "HELP") == 0 || strcmp(command, "?") == 0) {
    print_help_menu();
    return;
  } else if (command[0] != '\0') {
    printf("Unknown command: '%s'. Type HELP for options.\r\nCMD> ", command);
    return;
  } else {
    printf("CMD> ");
    return;
  }

  if (opcode != 0) {
    esp_err_t err = server_send_command(opcode, NULL, 0U);
    if (err == ESP_OK) {
      printf("[TX] Command sent (opcode: 0x%02X). Waiting for response...\r\nCMD> ",
             opcode);
    } else {
      printf("[ERROR] Failed to send command: 0x%x\r\nCMD> ", err);
    }
  }
}

static void console_task(void *arg) {
  (void)arg;
  uint8_t *line;
  print_help_menu();

  while (1) {
    line = (uint8_t *)malloc(CMD_LINE_MAX_LEN);
    if (line == NULL) {
      ESP_LOGE(TAG, "Failed to allocate memory for command line");
      vTaskDelay(pdMS_TO_TICKS(100));
      continue;
    }

    int len = uart_read_bytes(PC_UART_NUM, line, CMD_LINE_MAX_LEN - 1,
                              portMAX_DELAY);
    if (len > 0) {
      line[len] = '\0';
      process_console_command((char *)line);
    }
    free(line);
  }

  vTaskDelete(NULL);
}

static void wireless_rx_task(void *arg) {
  (void)arg;
  wireless_packet_t pkt;

  while (1) {
    if (xQueueReceive(s_wireless_rx_queue, &pkt, portMAX_DELAY) == pdTRUE) {
      if (!proto_verify_frame(&pkt,
                             offsetof(wireless_packet_t, payload) +
                                 pkt.payload_len + sizeof(pkt.crc16))) {
        ESP_LOGW(TAG, "Discarded invalid wireless frame (CRC mismatch)");
        continue;
      }

      switch (pkt.opcode) {
      case RESP_READ_DATA:
        if (pkt.payload_len == sizeof(telemetry_record_t)) {
          telemetry_record_t record;
          memcpy(&record, pkt.payload, sizeof(record));
          display_record("OLDEST READ", &record);
        }
        break;

      case RESP_PEEK_DATA:
        if (pkt.payload_len == sizeof(telemetry_record_t)) {
          telemetry_record_t record;
          memcpy(&record, pkt.payload, sizeof(record));
          display_record("PEEK (UNFREED)", &record);
        }
        break;

      case RESP_BUFFER_EMPTY:
        printf("\r\n[NOTICE] Circular buffer is EMPTY.\r\nCMD> ");
        break;

      case RESP_STATUS_DATA:
        if (pkt.payload_len == sizeof(proto_diagnostics_payload_t)) {
          proto_diagnostics_payload_t diagnostics;
          memcpy(&diagnostics, pkt.payload, sizeof(diagnostics));
          display_diagnostics(&diagnostics);
        }
        break;

      case MSG_ACK:
        printf("\r\n[SUCCESS] Client acknowledged command execution.\r\nCMD> ");
        break;

      case MSG_NACK:
        printf("\r\n[REJECTED] Client rejected the command.\r\nCMD> ");
        break;

      case ALERT_BUFFER_FULL:
        if (pkt.payload_len == sizeof(proto_alert_full_payload_t)) {
          proto_alert_full_payload_t alert;
          memcpy(&alert, pkt.payload, sizeof(alert));
          printf("\r\n*** [CRITICAL EXCEPTION: 0xEFULL_MEM] BUFFER FULL ***\r\n"
                 "  Blocked write slot : #%lu\r\n"
                 "  Buffer capacity    : %lu\r\n"
                 "  Total exceptions   : %lu\r\n"
                 "  Client uptime      : %lu ms\r\n"
                 "  Send READ to free a slot.\r\n"
                 "CMD> ",
                 (unsigned long)alert.blocked_write_idx,
                 (unsigned long)alert.buffer_capacity,
                 (unsigned long)alert.total_exceptions,
                 (unsigned long)alert.timestamp_ms);
        }
        break;

      default:
        ESP_LOGW(TAG, "Unknown response opcode: 0x%02X", pkt.opcode);
        break;
      }
    }
  }
}

static void uart_event_task(void *arg) {
  (void)arg;
  uart_event_t event;
  uint8_t *data;

  while (1) {
    if (xQueueReceive(s_uart_event_queue, &event, portMAX_DELAY) == pdTRUE) {
      if (event.type == UART_DATA) {
        data = (uint8_t *)malloc(event.size);
        if (data == NULL) {
          ESP_LOGE(TAG, "Failed to allocate memory for UART data");
          uart_flush_input(PC_UART_NUM);
          xQueueReset(s_uart_event_queue);
          continue;
        }
        int len = uart_read_bytes(PC_UART_NUM, data, event.size, 0);
        if (len > 0) {
          // Data is handled in console_task via uart_read_bytes
        }
        free(data);
      } else if (event.type == UART_FIFO_OVF ||
                 event.type == UART_BUFFER_FULL) {
        ESP_LOGE(TAG, "UART buffer overflow");
        uart_flush_input(PC_UART_NUM);
        xQueueReset(s_uart_event_queue);
      }
    }
  }
}

static void init_uart(void) {
  const uart_config_t uart_config = {
      .baud_rate = PC_UART_BAUD_RATE,
      .data_bits = UART_DATA_8_BITS,
      .parity = UART_PARITY_DISABLE,
      .stop_bits = UART_STOP_BITS_1,
      .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
      .source_clk = UART_SCLK_DEFAULT,
  };

  ESP_ERROR_CHECK(uart_param_config(PC_UART_NUM, &uart_config));
  ESP_ERROR_CHECK(uart_set_pin(PC_UART_NUM, UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE,
                               UART_PIN_NO_CHANGE, UART_PIN_NO_CHANGE));
  ESP_ERROR_CHECK(uart_driver_install(
      PC_UART_NUM, UART_RX_BUF_SIZE, UART_TX_BUF_SIZE, UART_QUEUE_DEPTH,
      &s_uart_event_queue, 0));

  xTaskCreate(uart_event_task, "uart_event", 4096, NULL, 5, NULL);
}

static void init_wifi_espnow(void) {
  ESP_ERROR_CHECK(esp_netif_init());
  ESP_ERROR_CHECK(esp_event_loop_create_default());

  wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
  ESP_ERROR_CHECK(esp_wifi_init(&cfg));
  ESP_ERROR_CHECK(esp_wifi_set_storage(WIFI_STORAGE_RAM));
  ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
  ESP_ERROR_CHECK(esp_wifi_start());
  ESP_ERROR_CHECK(esp_wifi_set_channel(WIFI_CHANNEL, WIFI_SECOND_CHAN_NONE));

  ESP_ERROR_CHECK(esp_now_init());
  ESP_ERROR_CHECK(esp_now_register_recv_cb(on_esp_now_recv));

  esp_now_peer_info_t peer_info;
  memset(&peer_info, 0, sizeof(peer_info));
  memcpy(peer_info.peer_addr, s_broadcast_mac, ESP_NOW_ETH_ALEN);
  peer_info.channel = WIFI_CHANNEL;
  peer_info.encrypt = false;
  ESP_ERROR_CHECK(esp_now_add_peer(&peer_info));
}

void app_main(void) {
  ESP_LOGI(TAG, "=== ESP32 Circular Buffer Server Gateway Initializing ===");

  esp_err_t ret = nvs_flash_init();
  if ((ret == ESP_ERR_NVS_NO_FREE_PAGES) ||
      (ret == ESP_ERR_NVS_NEW_VERSION_FOUND)) {
    ESP_ERROR_CHECK(nvs_flash_erase());
    ret = nvs_flash_init();
  }
  ESP_ERROR_CHECK(ret);

  s_wireless_rx_queue = xQueueCreate(20, sizeof(wireless_packet_t));
  if (s_wireless_rx_queue == NULL) {
    ESP_LOGE(TAG, "Failed to create wireless RX queue");
    return;
  }

  init_uart();
  init_wifi_espnow();

  ESP_LOGI(TAG, "Server ready. Connect via Serial Monitor to send telecommands.");

  xTaskCreate(wireless_rx_task, "wireless_rx", 4096, NULL, 5, NULL);
  xTaskCreate(console_task, "console", 4096, NULL, 5, NULL);
}
