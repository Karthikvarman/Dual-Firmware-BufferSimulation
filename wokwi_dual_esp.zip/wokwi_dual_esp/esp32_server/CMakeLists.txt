cmake_minimum_required(VERSION 3.5)

set(PROJECT_NAME "esp32_server")

include($ENV{IDF_PATH}/tools/cmake/project.cmake)
project(${PROJECT_NAME})
